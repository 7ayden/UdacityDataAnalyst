import sys
import pickle
sys.path.append("../tools/")
from feature_format import featureFormat, targetFeatureSplit